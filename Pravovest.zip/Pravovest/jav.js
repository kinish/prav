document.getElementById("myButton").addEventListener("click", myFunction);

function myFunction(){
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
	localStorage.setItem('username', 'password');
    setTimeout(function(){window.open("https://internet.garant.ru/auth/login?username=" + username + "&password=" + password, "_blank");},1);
	localStorage.setItem('username', username);
localStorage.setItem('password', password);
}
window.onload = function() {
  var username = localStorage.getItem('username');
  var password = localStorage.getItem('password');
  if (username) {
    document.getElementById("username").value = username;
  }
  if (password) {
    document.getElementById("password").value = password;
  }
};



